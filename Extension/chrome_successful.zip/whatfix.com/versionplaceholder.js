window.wfx_version = "whatfix_version_placeholder";
